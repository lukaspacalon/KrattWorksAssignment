/** @file
 *  @brief MAVLink comm protocol built from standard.xml
 *  @see http://mavlink.org
 */
#pragma once
 
#ifndef MAVLINK_VERSION_H
#define MAVLINK_VERSION_H

#define MAVLINK_BUILD_DATE "Thu Aug 27 2026"
#define MAVLINK_WIRE_PROTOCOL_VERSION "2.0"
#define MAVLINK_MAX_DIALECT_PAYLOAD_SIZE 78
 
#endif // MAVLINK_VERSION_H
